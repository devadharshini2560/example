import java.util.Scanner;
public class Addition {

	public static void main(String[] args) {
	System.out.println("enter the numbers");
	Addition ad = new Addition();
	int num1 = ad.input();
	int num2 = ad.input();
	int res = ad.add(num1, num2);
	System.out.println("addition of two numbers is : "+res);
	
	}
    int  input()
{
    Scanner sc = new Scanner(System.in);
    
    int num = sc.nextInt();
    return num;
}
    int add(int firstnum, int secondnum) {
    	
    	return firstnum + secondnum;
    	
    }
}
